

const synth = window.speechSynthesis

function getVoice(lang) {
  const voices = synth.getVoices()
  return voices.filter(v => v.lang === lang)[0]
}

function yingshi(shiju) {
  let utterThis = new SpeechSynthesisUtterance(shiju)
  utterThis.voice = getVoice('zh-CN')
  console.log(utterThis.voice.name)
  synth.speak(utterThis)
}


